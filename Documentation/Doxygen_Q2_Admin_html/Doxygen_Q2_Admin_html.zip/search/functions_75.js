var searchData=
[
  ['updatedatatransferprogress',['updateDataTransferProgress',['../class_main_window.html#ad283ce4bfa32259392fe9a5574cafc75',1,'MainWindow']]]
];
