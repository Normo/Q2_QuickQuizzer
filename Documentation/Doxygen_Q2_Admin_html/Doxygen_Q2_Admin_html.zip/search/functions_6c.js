var searchData=
[
  ['loadinifile',['loadIniFile',['../class_main_window.html#a0d2b6ec2eed31d51430061bbf3042a37',1,'MainWindow']]]
];
