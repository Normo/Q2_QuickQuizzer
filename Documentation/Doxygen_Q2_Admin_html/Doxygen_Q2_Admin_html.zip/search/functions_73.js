var searchData=
[
  ['setupui',['setupUi',['../class_ui___main_window.html#acf4a0872c4c77d8f43a2ec66ed849b58',1,'Ui_MainWindow']]],
  ['showinfobox',['showInfobox',['../class_main_window.html#ae3d7fe0907fe6f83b0c8e11a0496ce0b',1,'MainWindow']]]
];
