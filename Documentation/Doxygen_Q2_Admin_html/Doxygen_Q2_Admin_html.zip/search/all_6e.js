var searchData=
[
  ['newintkeyvalues',['newIntKeyValues',['../class_main_window.html#a4ddfa99124c7b29fb0722ada0281e4bb',1,'MainWindow']]],
  ['newstringkeyvalues',['newStringKeyValues',['../class_main_window.html#ac35825b510d063a8cb79b41d67e87593',1,'MainWindow']]],
  ['nstatlabel',['nStatlabel',['../class_main_window.html#ae134c0b72ed4c17201ce217a62368d57',1,'MainWindow']]]
];
