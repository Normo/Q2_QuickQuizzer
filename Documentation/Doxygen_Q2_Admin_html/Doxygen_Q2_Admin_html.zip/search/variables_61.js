var searchData=
[
  ['actiondeutsch',['actionDeutsch',['../class_ui___main_window.html#a9a57043ec3bb22857a54f75a59574651',1,'Ui_MainWindow']]],
  ['actionenglisch',['actionEnglisch',['../class_ui___main_window.html#a56f3308ba409e4bfe97b5268eb7b1efe',1,'Ui_MainWindow']]],
  ['actionexit',['actionExit',['../class_ui___main_window.html#ae8370529640da51b50cd1fb5be677c02',1,'Ui_MainWindow']]],
  ['actioninfo',['actionInfo',['../class_ui___main_window.html#af55fe01495c55c9baf7611571c6b6158',1,'Ui_MainWindow']]]
];
