var searchData=
[
  ['qtranslator',['qTranslator',['../main_8cpp.html#a3f2f9117e4f511f2bd9096d2e620b36e',1,'qTranslator():&#160;main.cpp'],['../mainwindow_8cpp.html#a3f2f9117e4f511f2bd9096d2e620b36e',1,'qTranslator():&#160;main.cpp']]],
  ['query',['query',['../class_d_b_handler.html#aba3ad3d2bbe58915709e1f35d13cb1fe',1,'DBHandler']]]
];
