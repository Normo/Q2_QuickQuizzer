var searchData=
[
  ['actiondeutschonclick',['actionDeutschOnClick',['../class_main_window.html#a93fcfad228df43ca7baa26bfc4169e41',1,'MainWindow']]],
  ['actionenglischonclick',['actionEnglischOnClick',['../class_main_window.html#a5fc6f5227ac6a561f3b58b10ef9e72ef',1,'MainWindow']]],
  ['actionexitonclick',['actionExitOnClick',['../class_main_window.html#a79c21ad373bd9539f593947f5cbe9018',1,'MainWindow']]],
  ['actioninfoonclick',['actionInfoOnClick',['../class_main_window.html#a4eff5cd64c18fb4a46f71916fc13a7c8',1,'MainWindow']]]
];
