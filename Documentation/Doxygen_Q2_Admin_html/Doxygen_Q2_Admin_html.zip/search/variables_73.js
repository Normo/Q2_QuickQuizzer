var searchData=
[
  ['scrollarea',['scrollArea',['../class_ui___main_window.html#ac5779d53b47a565785fec252abb1b3c6',1,'Ui_MainWindow']]],
  ['scrollareawidgetcontents',['scrollAreaWidgetContents',['../class_ui___main_window.html#aa70fc2af9f9ea3b686db12823c5deb47',1,'Ui_MainWindow']]],
  ['spinbox_5fftpport',['spinBox_ftpPort',['../class_ui___main_window.html#af8574a8de44ff15f743fc839112a13ff',1,'Ui_MainWindow']]],
  ['spinbox_5fgamesettings_5fdelayq_5fa',['spinBox_gameSettings_DelayQ_A',['../class_ui___main_window.html#a6ebd6c72d46f9f23228caa5b57a5c8dd',1,'Ui_MainWindow']]],
  ['spinbox_5fgamesettings_5fhscount',['spinBox_gameSettings_HSCount',['../class_ui___main_window.html#a4fbe9b6a79d80f75a1d81d0f050e00a1',1,'Ui_MainWindow']]],
  ['spinbox_5fgamesettings_5fminusercount',['spinBox_gameSettings_MinUserCount',['../class_ui___main_window.html#ad130c04e00682416cdadcec48244df22',1,'Ui_MainWindow']]],
  ['spinbox_5fgamesettings_5fnailcount',['spinBox_gameSettings_NailCount',['../class_ui___main_window.html#a2255dc8919b0a999fbc49ff4cac2ff3b',1,'Ui_MainWindow']]],
  ['spinbox_5fgamesettings_5frounds',['spinBox_gameSettings_Rounds',['../class_ui___main_window.html#a56e32e40f110ca75f6b4782767963827',1,'Ui_MainWindow']]],
  ['spinbox_5fgamesettings_5ftimeperq',['spinBox_gameSettings_TimePerQ',['../class_ui___main_window.html#aa851df685dc090976422f6d6e9cb4c47',1,'Ui_MainWindow']]],
  ['spinbox_5fgamesettings_5ftimesperc',['spinBox_gameSettings_TimesPerC',['../class_ui___main_window.html#ad423c40bfb71c3b8bc27bce29469bcdc',1,'Ui_MainWindow']]],
  ['spinbox_5fgamesettings_5ftimewhennailed',['spinBox_gameSettings_TimeWhenNailed',['../class_ui___main_window.html#a190c97e5e66b74072c17719a192023ef',1,'Ui_MainWindow']]],
  ['statusbar',['statusBar',['../class_ui___main_window.html#a50fa481337604bcc8bf68de18ab16ecd',1,'Ui_MainWindow']]],
  ['stringkeyvalues',['stringKeyValues',['../class_file_handler.html#a28dbe37360458061c4b8ce6438b6f326',1,'FileHandler']]]
];
