var searchData=
[
  ['actiondeutsch',['actionDeutsch',['../class_ui___main_window.html#a9a57043ec3bb22857a54f75a59574651',1,'Ui_MainWindow']]],
  ['actiondeutschonclick',['actionDeutschOnClick',['../class_main_window.html#a93fcfad228df43ca7baa26bfc4169e41',1,'MainWindow']]],
  ['actionenglisch',['actionEnglisch',['../class_ui___main_window.html#a56f3308ba409e4bfe97b5268eb7b1efe',1,'Ui_MainWindow']]],
  ['actionenglischonclick',['actionEnglischOnClick',['../class_main_window.html#a5fc6f5227ac6a561f3b58b10ef9e72ef',1,'MainWindow']]],
  ['actionexit',['actionExit',['../class_ui___main_window.html#ae8370529640da51b50cd1fb5be677c02',1,'Ui_MainWindow']]],
  ['actionexitonclick',['actionExitOnClick',['../class_main_window.html#a79c21ad373bd9539f593947f5cbe9018',1,'MainWindow']]],
  ['actioninfo',['actionInfo',['../class_ui___main_window.html#af55fe01495c55c9baf7611571c6b6158',1,'Ui_MainWindow']]],
  ['actioninfoonclick',['actionInfoOnClick',['../class_main_window.html#a4eff5cd64c18fb4a46f71916fc13a7c8',1,'MainWindow']]]
];
