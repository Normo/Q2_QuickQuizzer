var searchData=
[
  ['record',['record',['../class_d_b_handler.html#a9259ec172f200b4a613aad7ef30f453c',1,'DBHandler::record()'],['../class_main_window.html#a321b6d415a1840dfc56129566f08a39c',1,'MainWindow::record()']]],
  ['retranslateui',['retranslateUi',['../class_ui___main_window.html#a097dd160c3534a204904cb374412c618',1,'Ui_MainWindow']]]
];
