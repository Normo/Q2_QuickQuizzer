var searchData=
[
  ['dbhandler',['DBHandler',['../class_d_b_handler.html',1,'']]]
];
