var searchData=
[
  ['btn_5fadd',['btn_add',['../class_ui___main_window.html#add4ea31254d17f6cd529389c2565dafc',1,'Ui_MainWindow']]],
  ['btn_5fdbconnect',['btn_dbConnect',['../class_ui___main_window.html#a7d4eb149126a0360c803d23e1279e343',1,'Ui_MainWindow']]],
  ['btn_5fdbdisconnect',['btn_dbDisconnect',['../class_ui___main_window.html#a1fe8c60074494d085f255c4d40eecdcd',1,'Ui_MainWindow']]],
  ['btn_5fdelete',['btn_delete',['../class_ui___main_window.html#afccd9c94f9a4d273770a0bc4a7dd3219',1,'Ui_MainWindow']]],
  ['btn_5fdiscardchanges',['btn_discardChanges',['../class_ui___main_window.html#aac262e57156c893bca18bc2b9350cb6e',1,'Ui_MainWindow']]],
  ['btn_5fedit',['btn_edit',['../class_ui___main_window.html#aff36f8863bc11980c3561edfaabb1b23',1,'Ui_MainWindow']]],
  ['btn_5fftpdisconnect',['btn_ftpDisconnect',['../class_ui___main_window.html#a68fc5c624e96d11d828d69e04fb03eec',1,'Ui_MainWindow']]],
  ['btn_5floadsettings',['btn_loadSettings',['../class_ui___main_window.html#a32588e303ddcf405328bc6e8cddb567a',1,'Ui_MainWindow']]],
  ['btn_5fsave',['btn_save',['../class_ui___main_window.html#a251b17e112289430adf3878236a970b3',1,'Ui_MainWindow']]],
  ['btn_5fsendsettings',['btn_sendSettings',['../class_ui___main_window.html#a595850db5b7a2d1f06764e9e883b2cf6',1,'Ui_MainWindow']]]
];
