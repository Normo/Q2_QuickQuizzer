var searchData=
[
  ['windowicon',['windowIcon',['../class_main_window.html#ac275113bba7e1d2a8da990f085735967',1,'MainWindow']]]
];
